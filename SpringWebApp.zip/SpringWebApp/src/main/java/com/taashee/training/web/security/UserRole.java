package com.taashee.training.web.security;
import static com.taashee.training.web.security.UserPermission.*;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
public enum UserRole {
    ADMIN(Set.of(READ,WRITE)),
	USER(Set.of(READ));
	
	private final Set<UserPermission> permissions;

	public Set<UserPermission> getPermissions() {
		return permissions;
	}

	private UserRole(Set<UserPermission> permissions) {
		this.permissions = permissions;
	}
	
	public Set<SimpleGrantedAuthority>  getGrantedAuthorities(){
		Set<SimpleGrantedAuthority> grantedAuthorities=getPermissions()
				.stream().map(permission -> new SimpleGrantedAuthority(permission.getPermission())).collect(Collectors.toSet());
		return grantedAuthorities;
	}
}
