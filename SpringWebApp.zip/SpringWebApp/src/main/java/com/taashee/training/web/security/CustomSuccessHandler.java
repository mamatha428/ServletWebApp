package com.taashee.training.web.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Service;

@Service
public class CustomSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
	private final RedirectStrategy redirectStrategy=new DefaultRedirectStrategy();
	   @Override
       public void onAuthenticationSuccess(HttpServletRequest request,HttpServletResponse response,Authentication authentication) throws IOException{
    	   if(isAdminAuthority(authentication)) {
    		   redirectStrategy.sendRedirect(request, response, "/hobby/addHobbyForm");
    	   }
    	   else
		   redirectStrategy.sendRedirect(request, response, "/hobby/all");
       }
	private boolean isAdminAuthority(Authentication authentication) {
		//here ROLE_ADMIN-> ADMIN is the role there in Hobby table
		return authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
}
