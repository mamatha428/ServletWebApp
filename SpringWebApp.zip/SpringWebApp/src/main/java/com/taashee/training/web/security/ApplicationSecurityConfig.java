package com.taashee.training.web.security;

import static com.taashee.training.web.security.UserPermission.WRITE;
import static com.taashee.training.web.security.UserPermission.READ;

import static com.taashee.training.web.security.UserRole.ADMIN;
import static com.taashee.training.web.security.UserRole.USER;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled=true)
public class ApplicationSecurityConfig extends WebSecurityConfigurerAdapter{
	
/*	@Autowired
//	private CustomSuccessHandler successHandler;
//	@Autowired
	private PasswordEncoder passwordEncoder;*/
	
//	public ApplicationSecurityConfig(PasswordEncoder passwordEncoder) {
//		this.passwordEncoder = passwordEncoder;
//	}
//	
//	public ApplicationSecurityConfig(CustomSuccessHandler successHandler) {
//		this.successHandler = successHandler;
//	}
	private CustomSuccessHandler successHandler;
	private PasswordEncoder passwordEncoder;
	private UserDetailsService userDetailsService;
	  /*  @Autowired
	    public ApplicationSecurityConfig(CustomSuccessHandler successHandler, PasswordEncoder passwordEncoder) {
	        this.successHandler = successHandler;
	        this.passwordEncoder = passwordEncoder;
	        String encodedPassword=this.passwordEncoder.encode("password");
	        System.out.println("password:"+encodedPassword);
	    }*/
	    @Autowired
	    public ApplicationSecurityConfig(CustomSuccessHandler successHandler, PasswordEncoder passwordEncoder,
	    		UserDetailsService userDetailsService) {
	    	this.successHandler = successHandler;
	    	this.passwordEncoder = passwordEncoder;
	    	String encodedPassword=this.passwordEncoder.encode("password");
		    System.out.println("password:"+encodedPassword);
	    	this.userDetailsService = userDetailsService;
	    }
	@Override
      protected void configure(HttpSecurity http) throws Exception {
    	  http.csrf().disable()
    	  .authorizeRequests()
    	  .antMatchers("/","index").permitAll()
    	  .antMatchers(HttpMethod.POST,"/api/hobby/**").hasAuthority(WRITE.getPermission())
    	  .antMatchers(HttpMethod.GET,"/api/hobby/**").hasAuthority(READ.getPermission())
    	  .antMatchers(HttpMethod.PUT,"/api/hobby/**").hasAuthority(WRITE.getPermission())
    	  .antMatchers(HttpMethod.DELETE,"/api/hobby/**").hasAuthority(WRITE.getPermission())
          .anyRequest()
    	//  .permitAll()
    	  .authenticated()
    	  .and()
    	//  .formLogin()
    	//  .successHandler(successHandler);
    	 
    	//  .loginPage("/login").permitAll();
    	  .httpBasic()
    	  ;
      }
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) {
		auth.authenticationProvider(daoAuthenticationProvider());
	}
	@Bean
	public DaoAuthenticationProvider daoAuthenticationProvider() {
		DaoAuthenticationProvider provider=new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(passwordEncoder); 
		return provider;
	}
	//$2a$10$PaMDYUTtzGieBkGH88qcHuE2/DaAFtITf1FvGwYwrj6M5LNRhngDe
	protected UserDetailsService userDetailsService() {
		UserDetails kingUser=User.builder().username("king").password(passwordEncoder.encode("password"))
				.authorities(ADMIN.getGrantedAuthorities()).build();
		UserDetails queenUser=User.builder().username("mamatha").password(passwordEncoder.encode("password"))
				.authorities(USER.getGrantedAuthorities()).build();
        return new InMemoryUserDetailsManager(kingUser,queenUser);
	}
}
