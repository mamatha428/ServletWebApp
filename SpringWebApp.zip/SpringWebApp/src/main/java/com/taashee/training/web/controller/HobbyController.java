package com.taashee.training.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.taashee.training.web.model.Hobby;
import com.taashee.training.web.service.HobbyService;

@Controller
@RequestMapping("/hobby")
public class HobbyController {
	private final HobbyService hobbyService;
	@Autowired
	public HobbyController(HobbyService hobbyService) {
		this.hobbyService=hobbyService;
	}
	
     @GetMapping(value="/all")
     @PreAuthorize(value="hasRole('ADMIN')")
     public String showDefaultPage(ModelMap modelMap) {
    	 List<Hobby> hobbies=hobbyService.getAllHobbies();
		 modelMap.put("hobbies", hobbies);
		 System.out.println(hobbies.size());
		 return "hobby-list";
     }
     @GetMapping(value="/hello")
     public String showingDefaultPage(){
    	return "index";
    }
     
     @GetMapping(value="/addHobbyForm")
     public String showAddHobbyForm() {
    	 return "add-hobby-form";
     }
     
     @GetMapping(value="/updateHobbyForm")
     public String showUpdateHobbyForm(@RequestParam int id,ModelMap modelMap) {
    	 Hobby hobby=hobbyService.getHobbyById(id);
    	 System.out.println(hobby.getName());
    	 modelMap.put("hobby", hobby);
    	 return "add-hobby-form";
     }
     
     @GetMapping(value="/deleteHobby")
     public String deleteHobby(@RequestParam int id) {
    	 hobbyService.deleteHobby(id);
    	 return "redirect:/hobby/all";
     }
     
     @PostMapping(value="/addHobby")
     public String addHobby(@RequestParam String name,@RequestParam String addedBy,@RequestParam String type,ModelMap modelMap){
    	  hobbyService.addHobby(new Hobby(null,name,addedBy,type));
    	  return showDefaultPage(modelMap);
    	 
     }
     
     @PostMapping(value="/updateHobby")
     public String updateHobby(@RequestParam int id,@RequestParam String name,@RequestParam String addedBy,@RequestParam String type) {
    	 Hobby hobby=new Hobby(id,name,addedBy,type);
    	 hobbyService.updateHobby(hobby);
    	 return "redirect:/hobby/all";
     }
     
}
