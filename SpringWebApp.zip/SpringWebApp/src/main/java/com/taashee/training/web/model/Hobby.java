package com.taashee.training.web.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.taashee.training.web.security.UserRole;

@Entity(name="hobby")
public class Hobby implements UserDetails {
	@Id
	private Integer id;
	private String name;
    private String addedBy;
    private String type;
  
	private String username;
    private String password;
    private String role;
    
    public Hobby() {}
    public Hobby(String name, String addedBy, String type) {
		this.name = name;
		this.addedBy = addedBy;
		this.type = type;
	}
    public Hobby(Integer id,String name, String addedBy, String type) {
		this.id=id;
    	this.name = name;
		this.addedBy = addedBy;
		this.type = type;
	}
    public int getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	  public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public void setPassword(String password) {
			this.password = password;
		}
	@Override
	public Set<SimpleGrantedAuthority> getAuthorities() {
		UserRole userRole=UserRole.USER;
		if(role.equalsIgnoreCase(UserRole.ADMIN.name()))
			userRole=UserRole.ADMIN;
		
		Set<SimpleGrantedAuthority> permissions=userRole.getGrantedAuthorities();
		permissions.add(new SimpleGrantedAuthority("ROLE_"+role));
		return permissions;
			
	}
	@Override
	public String getPassword() {
		
		return password;
	}
	@Override
	public String getUsername() {
		
		return username;
	}
	@Override
	public boolean isAccountNonExpired() {
		
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		
		return true;
	}
	@Override
	public boolean isEnabled() {
		
		return true;
	}

}
