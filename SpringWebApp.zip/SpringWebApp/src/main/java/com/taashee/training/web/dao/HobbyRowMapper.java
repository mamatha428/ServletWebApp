package com.taashee.training.web.dao;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.taashee.training.web.model.Hobby;

public class HobbyRowMapper implements RowMapper<Hobby> {

	@Override
	public Hobby mapRow(ResultSet rs,int rowNum) throws SQLException {
		Hobby hobby=new Hobby();
		hobby.setId(rs.getInt("id"));
		hobby.setName(rs.getString("name"));
		hobby.setAddedBy(rs.getString("added_by"));
		hobby.setType(rs.getString("type"));
		hobby.setUsername(rs.getString("username"));
		hobby.setPassword(rs.getString("password"));
		hobby.setRole(rs.getString("role"));
		return hobby;
	}

	
}
