package com.taashee.training.web.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.taashee.training.web.model.Hobby;

@Repository
public interface HobbyRepository extends JpaRepository<Hobby,Integer>{
  //  @Query("SELECT h from Hobby h where username = ?1")
//	Hobby getUserByUsername(String username);

}
