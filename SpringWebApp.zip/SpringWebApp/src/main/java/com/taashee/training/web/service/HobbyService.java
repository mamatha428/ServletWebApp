package com.taashee.training.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taashee.training.web.config.CustomAppConfiguration;
import com.taashee.training.web.dao.HobbyJdbcDAO;
import com.taashee.training.web.dao.HobbyRepository;
import com.taashee.training.web.model.Hobby;

@Service
public class HobbyService {
    private final HobbyJdbcDAO hobbyJdbcDao;
    private final HobbyRepository hobbyRepository;
    @Autowired
    private CustomAppConfiguration customAppConfiguration;
   //writing the parameterized constructor 
    @Autowired
    public HobbyService(HobbyJdbcDAO hobbyJdbcDao,HobbyRepository hobbyRepository) {
    	this.hobbyJdbcDao=hobbyJdbcDao;
    	this.hobbyRepository=hobbyRepository;
    }
    public List<Hobby> getAllHobbies(){
    	List<Hobby> hobbies=hobbyJdbcDao.getAllHobbies();
    //	System.out.println("URL:"+customAppConfiguration.getUrl()+","+customAppConfiguration.getState());
    	return hobbyRepository.findAll();
    }
	public void addHobby(Hobby hobby) {
		//Hobby hobby=new Hobby(hobby.getName(),hobby.getAddedBy(),hobby.getType());
		//return hobbyJdbcDao.addHobby(hobby);
		Hobby savedHobby=hobbyRepository.save(hobby);
		
	}
	public void deleteHobby(int id) {
		//return hobbyJdbcDao.deleteHobby(id);
		hobbyRepository.deleteById(id);
	}
	public void updateHobby(Hobby hobby) {
		//return hobbyJdbcDao.updateHobby(hobby);
		Hobby savedHobby=hobbyRepository.save(hobby);
		
	}
	public Hobby getHobbyById(int id) {
	//	return hobbyJdbcDao.getHobbyById(id);
		return hobbyRepository.findById(id).orElse(new Hobby());
	}
}
