
package com.taashee.training.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.training.web.model.Hobby;
import com.taashee.training.web.service.HobbyService;

@RestController
@RequestMapping("/api/hobby")
public class HobbyRestController {
	private final HobbyService hobbyService;
	@Autowired
	public HobbyRestController(HobbyService hobbyService) {
		this.hobbyService=hobbyService;
	}
	
     @GetMapping(value="/all")
     @PreAuthorize(value="hasRole('ADMIN')")
     public ResponseEntity<List<Hobby>> showDefaultPage() {
    	 List<Hobby> hobbies=hobbyService.getAllHobbies();
		 System.out.println(hobbies.size());
		 return  ResponseEntity.ok(hobbies);
     }
     @GetMapping(value="/hello")
     public String showingDefaultPage(){
    	return "index";
    }
   
     @DeleteMapping
     public ResponseEntity deleteHobby(@RequestParam int id) {
    	 hobbyService.deleteHobby(id);
    	 return new ResponseEntity(HttpStatus.OK);
     }
     
     @PostMapping
     public ResponseEntity addHobby(@RequestBody Hobby hobby){
    	  hobbyService.addHobby(hobby);
    	  return new ResponseEntity(HttpStatus.CREATED);
    	 
     }
     
     @PutMapping
     public ResponseEntity updateHobby(@RequestBody Hobby hobby) {
    	 hobbyService.updateHobby(hobby);
    	 return new ResponseEntity(HttpStatus.OK);
     }
     
}
