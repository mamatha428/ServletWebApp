package com.taashee.training.web.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

import com.taashee.training.web.model.Hobby;

@Repository
public class HobbyJdbcDAO {
    private static final String GET_ALL_HOBBIES_QUERY = "SELECT * from Hobby";
	private static final String ADD_HOBBY_QUERY = "Insert into Hobby(name,added_by,type) values (?,?,?)";
	private static final String DELETE_HOBBY_QUERY = "Delete from Hobby where id = ?";
	private static final String UPDATE_HOBBY_QUERY = "UPDATE HOBBY SET NAME=?, ADDED_BY=?, TYPE=? WHERE ID=?";
	private static final String GET_HOBBY_BY_ID_QUERY = "select *from Hobby where id = ?";
	private static final String GET_HOBBY_BY_USERNAME_QUERY ="select *from Hobby where username = ?";
	private JdbcTemplate jdbcTemplate;
	//here also writing the parameterized constructor
	@Autowired
	public HobbyJdbcDAO(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
	}
	public List<Hobby> getAllHobbies() {
		return jdbcTemplate.query(GET_ALL_HOBBIES_QUERY, new HobbyRowMapper());
		
	}
	public int addHobby(Hobby hobby) {
		return jdbcTemplate.update(ADD_HOBBY_QUERY,new Object[] {hobby.getName(),hobby.getAddedBy(),hobby.getType()});
	}
	public int deleteHobby(int id) {
		return  jdbcTemplate.update(DELETE_HOBBY_QUERY,new Object[] {id});

	}
	public int updateHobby(Hobby hobby) {
		return jdbcTemplate.update(UPDATE_HOBBY_QUERY,new Object[] {hobby.getName(),hobby.getAddedBy(),hobby.getType(),hobby.getId()});
	}
	public Hobby getHobbyById(int id) {
		return jdbcTemplate.queryForObject(GET_HOBBY_BY_ID_QUERY,new Object[] {id},new HobbyByIdRowMapper());
	}
	public UserDetails getUserByUsername(String username) {
		return jdbcTemplate.queryForObject(GET_HOBBY_BY_USERNAME_QUERY, new HobbyRowMapper(),new Object[] {username});
	}
   
}
