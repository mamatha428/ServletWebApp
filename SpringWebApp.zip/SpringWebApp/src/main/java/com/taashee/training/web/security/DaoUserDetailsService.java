package com.taashee.training.web.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.taashee.training.web.dao.HobbyJdbcDAO;
import com.taashee.training.web.dao.HobbyRepository;

@Service
public class DaoUserDetailsService implements UserDetailsService {
	@Autowired
    HobbyJdbcDAO hobbyDao;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDetails user=hobbyDao.getUserByUsername(username);
		return user;
	}

}
