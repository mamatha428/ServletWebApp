package com.taashee.work.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class ConnectionFactory {
	private static Connection con;
	private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
	//ConnectionFactory cf=new ConnectionFactory();
	private static String URL="jdbc:mysql://localhost:3306/Journaling_app";
	private static String USERNAME="root";
	private static String PASSWORD="rgukt123";
	/*public ConnectionFactory() {
    	try {
			Class.forName(DRIVER_CLASS);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}*/
	
    public static Connection getConnection() {
    	//establishing connection
    //	Connection con=null;
    //	if(Objects.nonNull(con)) {//if we keep this , after connection close it is showing that after con close then it won't retrieve values
    //		return con;
    //	}
    	try {
    		Class.forName(DRIVER_CLASS);

			con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	 catch (ClassNotFoundException e) {
 			e.printStackTrace();
 		}
    	
    	return con;
    }
}
