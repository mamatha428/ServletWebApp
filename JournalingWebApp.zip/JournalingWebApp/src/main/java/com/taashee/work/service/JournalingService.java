package com.taashee.work.service;

import java.util.List;

import com.taashee.work.dao.JournalEntryDAO;
import com.taashee.work.dao.UserDAO;
import com.taashee.work.model.JournalEntry;
import com.taashee.work.model.User;

public class JournalingService {

    private JournalEntryDAO journalEntryDAO = new JournalEntryDAO();
    private UserDAO userDAO = new UserDAO();
   
    // Authenticate user by username and password
    public User authenticateUser(String username, String password) {
        return userDAO.getUserByUsernameAndPassword(username, password);
    }
    public void addEntry(JournalEntry entry) {
        journalEntryDAO.addEntry(entry); // Call DAO to insert the entry into the database
    }
    public void deleteEntry(int entryId) {
        journalEntryDAO.deleteEntry(entryId);
    }
    public JournalEntry getEntryById(int entryId) {
        return journalEntryDAO.getEntryById(entryId);
    }

    public void updateEntry(JournalEntry entry) {
        journalEntryDAO.updateEntry(entry);
    }

    public List<JournalEntry> getEntriesByUserId(int userId) {
        return journalEntryDAO.getEntriesByUserId(userId);
    }


}
