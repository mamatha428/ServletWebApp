package com.taashee.work.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.taashee.work.dao.ConnectionFactory;
import com.taashee.work.model.User;

public class UserDAO {
	  private static final String ADD_USER_QUERY = "INSERT INTO users (username, password) VALUES (?, ?)";
	  private static final String GET_USER_BY_CREDENTIALS_QUERY = "SELECT * FROM users WHERE username = ? AND password = ?";

	// Add new user
    public int addUser(User user) {
       int rowsAdded=0;
    	try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(ADD_USER_QUERY)){
    		ps.setString(1, user.getUsername());
    		ps.setString(2, user.getPassword());
    		rowsAdded=ps.executeUpdate();
    	}
    	 catch (SQLException e) {
             e.printStackTrace();
    	 }
    	
		return rowsAdded;
    	
    }
    
    // Get user by username and password
    public User getUserByUsernameAndPassword(String username, String password) {
        User user = null;
        try (Connection con = ConnectionFactory.getConnection(); 
             PreparedStatement ps = con.prepareStatement(GET_USER_BY_CREDENTIALS_QUERY)) {
            
            ps.setString(1, username);
            ps.setString(2, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    user = new User(
                        rs.getString("username"),
                        rs.getString("password")
                    );
                    user.setUserId(rs.getInt("user_id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
}


