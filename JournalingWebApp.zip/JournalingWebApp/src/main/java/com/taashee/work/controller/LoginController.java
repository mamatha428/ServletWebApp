package com.taashee.work.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.taashee.work.model.User;
import com.taashee.work.service.JournalingService;

@WebServlet({"/loginForm", "/login","/logout"})
public class LoginController extends HttpServlet {
    
    static JournalingService journalingService = new JournalingService();

    // Show login form
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        System.out.printf("\nServlet Path:%s\n",action);
        if ("/loginForm".equals(action)) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
        else if ("/logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect("login.jsp");
        }

        else {
            System.out.println("Not a valid action/URL");
        }
    }

    // Handle login attempt
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        System.out.printf("\nServlet Path:%s\n",action);
        if ("/login".equals(action)) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            User user = journalingService.authenticateUser(username, password);
            
            if (user != null) {
                // Store the user in session
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                
                // Redirect to the dashboard or journaling page
                response.sendRedirect("dashboard");
            } else {
                // Invalid credentials, show error message
                request.setAttribute("error", "Invalid username or password.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
                dispatcher.forward(request, response);
            }
        }
    }
}
