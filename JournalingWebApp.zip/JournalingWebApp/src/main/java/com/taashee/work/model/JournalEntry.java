package com.taashee.work.model;

import com.google.protobuf.Timestamp;

public class JournalEntry {
	private int entryId;
    private int userId;
    private String title;
    private String content;
    private java.sql.Timestamp timestamp;
    
    public int getEntryId() {
		return entryId;
	}
	public void setEntryId(int entryId) {
		this.entryId = entryId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public java.sql.Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(java.sql.Timestamp timestamp2) {
		this.timestamp = timestamp2;
	}
		

}
