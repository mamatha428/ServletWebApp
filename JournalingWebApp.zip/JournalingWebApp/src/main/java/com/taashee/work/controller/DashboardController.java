package com.taashee.work.controller;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.taashee.work.dao.ConnectionFactory;
import com.taashee.work.model.User;
import com.taashee.work.service.JournalingService;
import com.taashee.work.model.JournalEntry;

@WebServlet("/dashboard")
public class DashboardController extends HttpServlet {
    static JournalingService journalingService = new JournalingService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<JournalEntry> entries = journalingService.getEntriesByUserId(user.getUserId());

        request.setAttribute("entries", entries);
        request.setAttribute("user", user);

        RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
        dispatcher.forward(request, response);
    }
}
