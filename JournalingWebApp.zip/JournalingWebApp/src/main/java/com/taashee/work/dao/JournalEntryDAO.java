package com.taashee.work.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.taashee.work.model.JournalEntry;

public class JournalEntryDAO {
    private static final String ADD_ENTRY_QUERY = "INSERT INTO entries (user_id, title, content) VALUES (?, ?, ?)";
	private static final String DELETE_ENTRY_QUERY ="DELETE FROM entries WHERE entry_id = ?";
	private static final String GET_ENTRY_BY_ID_QUERY = "SELECT * FROM entries WHERE entry_id = ?";
	private static final String UPDATE_ENTRY_QUERY = "UPDATE entries SET title = ?, content = ? WHERE entry_id = ?";
	private static final String GET_ENTRIES_BY_USERID_QUERY = "SELECT * FROM entries WHERE user_id = ?";

    // Add journal entry to database
    public int addEntry(JournalEntry entry) {
        int entriesAdded = 0;
        try (Connection con = ConnectionFactory.getConnection(); 
             PreparedStatement ps = con.prepareStatement(ADD_ENTRY_QUERY)) {
            
            ps.setInt(1, entry.getUserId());
            ps.setString(2, entry.getTitle());
            ps.setString(3, entry.getContent());
            
            entriesAdded = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entriesAdded;
    }
    
    public int deleteEntry(int entryId) {
     
        try (Connection con = ConnectionFactory.getConnection(); 
             PreparedStatement ps = con.prepareStatement(DELETE_ENTRY_QUERY)) {
            ps.setInt(1, entryId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

public JournalEntry getEntryById(int entryId) {
    try (Connection con = ConnectionFactory.getConnection();
         PreparedStatement ps = con.prepareStatement(GET_ENTRY_BY_ID_QUERY)) {
        
        ps.setInt(1, entryId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            JournalEntry entry = new JournalEntry();
            entry.setEntryId(rs.getInt("entry_id"));
            entry.setUserId(rs.getInt("user_id"));
            entry.setTitle(rs.getString("title"));
            entry.setContent(rs.getString("content"));
            entry.setTimestamp(rs.getTimestamp("timestamp"));
            return entry;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

public void updateEntry(JournalEntry entry) {
    try (Connection con = ConnectionFactory.getConnection();
         PreparedStatement ps = con.prepareStatement(UPDATE_ENTRY_QUERY)) {

        ps.setString(1, entry.getTitle());
        ps.setString(2, entry.getContent());
        ps.setInt(3, entry.getEntryId());

        ps.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public List<JournalEntry> getEntriesByUserId(int userId) {
    List<JournalEntry> entries = new ArrayList<>();

    try (Connection conn = ConnectionFactory.getConnection();
         PreparedStatement stmt = conn.prepareStatement(GET_ENTRIES_BY_USERID_QUERY)) {

        stmt.setInt(1, userId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            JournalEntry entry = new JournalEntry();
            entry.setEntryId(rs.getInt("entry_id"));
            entry.setUserId(rs.getInt("user_id"));
            entry.setTitle(rs.getString("title"));
            entry.setContent(rs.getString("content"));
            entry.setTimestamp(rs.getTimestamp("timestamp"));
            entries.add(entry);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return entries;
}

}
