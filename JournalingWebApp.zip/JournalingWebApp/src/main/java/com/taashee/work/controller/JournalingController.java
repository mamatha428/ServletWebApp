package com.taashee.work.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.taashee.work.model.JournalEntry;
import com.taashee.work.model.User;
import com.taashee.work.service.JournalingService;

@WebServlet({"/addEntryForm", "/addEntry","/editEntryForm","/updateEntry","/deleteEntry"})
public class JournalingController extends HttpServlet {
    static JournalingService journalingService = new JournalingService();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        System.out.printf("\nServlet Path:%s\n",action);
        switch (action) {
            case "/addEntryForm":
                HttpSession session = request.getSession();
                if (session.getAttribute("user") == null) {
                    response.sendRedirect("login.jsp"); // Redirect to login if user is not logged in
                    return;
                }
                RequestDispatcher dispatcher = request.getRequestDispatcher("add-entry.jsp");
                dispatcher.forward(request, response);
                break;
            case "/editEntryForm":
                int entryId = Integer.parseInt(request.getParameter("entryId"));
                JournalEntry entry = journalingService.getEntryById(entryId);
                request.setAttribute("entry", entry);
                request.getRequestDispatcher("edit-entry.jsp").forward(request, response);
                break;
            case "/deleteEntry":
                int entryIdToDelete = Integer.parseInt(request.getParameter("entryId"));
                journalingService.deleteEntry(entryIdToDelete);
                response.sendRedirect("dashboard");
                break;

                
            default:
                System.out.println("Not a valid action/URL");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        
        if ("/addEntry".equals(action)) {
            // get data from the form
            String title = request.getParameter("title");
            String content = request.getParameter("content");

            // Get user info from session
            HttpSession session = request.getSession();
            if (session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            int userId = ((User) session.getAttribute("user")).getUserId();

            // Create a JournalEntry object and set its properties
            JournalEntry entry = new JournalEntry();
            entry.setUserId(userId);
            entry.setTitle(title);
            entry.setContent(content);

            // Save the entry to the database
            journalingService.addEntry(entry);

            // Redirect to a confirmation or dashboard page
            response.sendRedirect("dashboard");
        }
        if ("/updateEntry".equals(action)) {
            int entryId = Integer.parseInt(request.getParameter("entryId"));
            String title = request.getParameter("title");
            String content = request.getParameter("content");

            JournalEntry entry = new JournalEntry();
            entry.setEntryId(entryId);
            entry.setTitle(title);
            entry.setContent(content);

            journalingService.updateEntry(entry);
            response.sendRedirect("dashboard");
        }
    }
}
