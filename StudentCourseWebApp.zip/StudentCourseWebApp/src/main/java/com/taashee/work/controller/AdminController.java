package com.taashee.work.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taashee.work.entity.Course;
import com.taashee.work.entity.Instructor;
import com.taashee.work.entity.Student;
import com.taashee.work.service.StudentCourseService;

@Controller
@RequestMapping(value="/admin")
public class AdminController {
	

	private final StudentCourseService studentCourseService;
	
	@Autowired
	public AdminController(StudentCourseService studentCourseService) {
		this.studentCourseService = studentCourseService;
	}
	
    @GetMapping("/dashboard")
    public String adminDashboard(ModelMap modelMap) {
    	List<Student> students=studentCourseService.getAllStudents();
    	List<Course> courses=studentCourseService.getAllCourses();
    	List<Instructor> instructors=studentCourseService.getAllInstructors();
    	modelMap.put("students", students);
    	modelMap.put("courses", courses);
    	modelMap.put("instructors", instructors);
    	return "admin-dashboard";
    }
}
