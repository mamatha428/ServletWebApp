package com.taashee.work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taashee.work.entity.Course;
import com.taashee.work.entity.Instructor;
import com.taashee.work.entity.Student;
import com.taashee.work.repository.CourseRepository;
import com.taashee.work.repository.InstructorRepository;
import com.taashee.work.repository.StudentRepository;

@Service
public class StudentCourseService {

	private final StudentRepository studentRepository;
	private final CourseRepository courseRepository;
	private final InstructorRepository instructorRepository;

	@Autowired
	public StudentCourseService(StudentRepository studentRepository, CourseRepository courseRepository,
			InstructorRepository instructorRepository) {
		this.studentRepository = studentRepository;
		this.courseRepository = courseRepository;
		this.instructorRepository = instructorRepository;
	}

	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	public List<Instructor> getAllInstructors() {
		return instructorRepository.findAll();
	}
	
	

}
