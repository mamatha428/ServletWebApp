package com.taashee.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.training.entity.AadharCard;
import com.taashee.training.entity.IndianCitizen;
import com.taashee.training.repository.AadharRepository;
import com.taashee.training.repository.CitizenRepository;

@RestController
@RequestMapping(value="/oneToOne")
public class oneToOneController {
	private final AadharRepository aadharRepository;
	private final CitizenRepository citizenRepository;
    
	@Autowired
	public oneToOneController(AadharRepository aadharRepository, CitizenRepository citizenRepository) {

		this.aadharRepository = aadharRepository;
		this.citizenRepository = citizenRepository;
	}
	
	@PostMapping(value="/aadhar")
	public AadharCard saveAadharCard(@RequestBody AadharCard aadhar) {
		return aadharRepository.save(aadhar);
	}
	
	@GetMapping(value="/aadhar/all")
	public List<AadharCard> getAllAadharCards(){
		return aadharRepository.findAll();
	}
	
	@PostMapping(value="/citizen")
	public IndianCitizen saveIndianCitizen(@RequestBody IndianCitizen citizen) {
		return citizenRepository.save(citizen);
	}
	
	@GetMapping(value="/citizen/all")
	public List<IndianCitizen> getAllIndianCitizens(){
		return citizenRepository.findAll();
	}
}
