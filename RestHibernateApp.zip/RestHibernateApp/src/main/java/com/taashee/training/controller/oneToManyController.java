package com.taashee.training.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.training.entity.Account;
import com.taashee.training.entity.Bank;
import com.taashee.training.repository.AccountRepository;
import com.taashee.training.repository.BankRepository;

@RestController
@RequestMapping(value="/oneToMany")
public class oneToManyController {

	private final BankRepository bankRepository;
	private final AccountRepository accountRepository;

	public oneToManyController(BankRepository bankRepository, AccountRepository accountRepository) {

		this.bankRepository = bankRepository;
		this.accountRepository = accountRepository;
	}
	
	@PostMapping(value="/bank")
	public Bank savingBankDetails(@RequestBody Bank bank) {
		return bankRepository.save(bank);
	}
	
	@PostMapping(value="/account")
	public Account saveAccounts(@RequestBody Account account) {
		return accountRepository.save(account);
	}
	
	@GetMapping(value="/bank/all")
	public List<Bank> getAllBanks(){
		return bankRepository.findAll();
	}
	
	@GetMapping(value="/account/all")
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}

}
