package com.taashee.training.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taashee.training.model.Hobby;
import com.taashee.training.service.HobbyService;

/**
 * Servlet implementation class HobbyController
 */
//@WebServlet("/HobbyController")
@WebServlet(urlPatterns={"/list","/addHobbyForm","/addHobby","/updateHobbyForm","/updateHobby","/deleteHobby"})
public class HobbyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private HobbyService hobbyService=new HobbyService();
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//response.sendRedirect("welcome.html");
		String action=request.getServletPath();
		System.out.printf("\nServlet Path:%s\n",action);
		switch(action) {
		case "/list":
			List<Hobby> hobbies=hobbyService.fetchAllHobbies();
			request.setAttribute("hobbies", hobbies);
			request.setAttribute("username", "Mamatha");
			
			RequestDispatcher dispatcher=request.getRequestDispatcher("hobby-list.jsp");
			dispatcher.forward(request, response);
			
			break;
		case "/addHobbyForm":
			//response.sendRedirect("add-hobby-form.jsp");
			   dispatcher = request.getRequestDispatcher("add-hobby-form.jsp");
			    dispatcher.forward(request, response);
			break;
		case "/addHobby":
			hobbyService.addHobby(request, response);
			break;
		case "/updateHobbyForm":
			hobbyService.updateHobbyForm(request,response);
			break;
		case "/updateHobby":
			hobbyService.updateHobby(request, response);
			break;
		case "/deleteHobby":
			hobbyService.deleteHobby(request, response);
			break;
		default:
			System.out.println("Not a valid action/URL");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
