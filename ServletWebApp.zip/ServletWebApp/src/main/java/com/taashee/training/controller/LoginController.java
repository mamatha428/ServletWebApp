package com.taashee.training.controller;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.taashee.training.service.HobbyService;

@WebServlet({"/login","/logout"})
public class LoginController extends HttpServlet {

   private final HobbyService hobbyService=new HobbyService();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action=request.getServletPath();
		if(action.equals("/logout")) {
			HttpSession session=request.getSession();
			session.invalidate();//cancels the session
		}
		response.sendRedirect("login.jsp");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		//method for authentication
		if(isAuthenticated(username,password)) {
			HttpSession session=request.getSession();
			session.setAttribute("loggedInUser", session);
			ServletContext servletContext=getServletContext();
		
		  Object sessions= servletContext.getAttribute("uniqueSessions");
		  int uniqueSessions=0;
		  if(Objects.nonNull(sessions)) {
			  uniqueSessions=(int) sessions+1;
		  }
		  else {
			  uniqueSessions+=1;
		  }
			servletContext.setAttribute("uniqueSessions", ++uniqueSessions);
				request.getRequestDispatcher("list").forward(request,response);

		}
		else {
			request.setAttribute("Message","Incorrect username or password");
	    	request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}


	private boolean isAuthenticated(String username, String password) {
		
		return hobbyService.areCredentialsCorrect(username,password);
	}

}
